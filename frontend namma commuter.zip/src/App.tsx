import { useState, type ReactNode } from "react";

const heroImage =
  "https://images.unsplash.com/photo-1774934879484-542f4102743f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=88&w=1800";
const metroImage =
  "https://images.unsplash.com/photo-1596796679119-7cf1a9e5448b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=88&w=1400";
const skylineImage =
  "https://images.unsplash.com/photo-1687158266872-fd2773fa76c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=88&w=1400";
const trafficImage =
  "https://images.unsplash.com/photo-1713450106884-502021ee5e61?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=88&w=1400";
const busImage =
  "https://images.unsplash.com/photo-1707158758017-03d2e2a8bbec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=88&w=1200";
const roadImage =
  "https://images.unsplash.com/photo-1650805915370-7c2f42b8276f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=88&w=1200";

const places = ["Majestic", "Indiranagar", "Whitefield", "Jayanagar", "Electronic City"];

function Icon({
  name,
  size = 20,
}: {
  name: "arrow" | "bus" | "cab" | "cloud" | "metro" | "pin" | "spark" | "swap" | "traffic" | "water" | "work";
  size?: number;
}) {
  const paths: Record<typeof name, ReactNode> = {
    arrow: <path d="m9 18 6-6-6-6" />,
    bus: (
      <>
        <path d="M8 6v6m8-6v6M6 17h12M7 3h10a2 2 0 0 1 2 2v10H5V5a2 2 0 0 1 2-2Z" />
        <circle cx="8" cy="19" r="1" />
        <circle cx="16" cy="19" r="1" />
      </>
    ),
    cab: (
      <>
        <path d="m5 11 1.5-4h11l1.5 4M4 11h16v6H4z" />
        <circle cx="7" cy="17" r="1" />
        <circle cx="17" cy="17" r="1" />
      </>
    ),
    cloud: (
      <path d="M7 18h10a4 4 0 0 0 .7-7.94A6 6 0 0 0 6.26 8.7 4.5 4.5 0 0 0 7 18Z" />
    ),
    metro: (
      <>
        <rect x="5" y="3" width="14" height="16" rx="3" />
        <path d="M8 7h8M8 15h.01M16 15h.01M8 21l2-2m6 0 2 2" />
      </>
    ),
    pin: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2" />
      </>
    ),
    spark: (
      <path d="m12 3 1.1 4.2L17 9l-3.9 1.8L12 15l-1.1-4.2L7 9l3.9-1.8L12 3Zm6 11 .6 2.4L21 17l-2.4.6L18 20l-.6-2.4L15 17l2.4-.6L18 14Z" />
    ),
    swap: (
      <>
        <path d="M7 7h11l-3-3m3 3-3 3M17 17H6l3 3m-3-3 3-3" />
      </>
    ),
    traffic: (
      <>
        <path d="M4 18h16M6 15l1.5-6h9L18 15" />
        <path d="M5 15h14v4H5zM9 9l1-3h4l1 3" />
      </>
    ),
    water: <path d="M12 3s6 6.2 6 11a6 6 0 1 1-12 0c0-4.8 6-11 6-11Z" />,
    work: (
      <>
        <path d="M4 8h16v11H4z" />
        <path d="M9 8V5h6v3m-11 4h16" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.8"
    >
      {paths[name]}
    </svg>
  );
}

function PhotoCard({
  image,
  alt,
  eyebrow,
  title,
}: {
  image: string;
  alt: string;
  eyebrow: string;
  title: string;
}) {
  return (
    <article className="photo-card">
      <img src={image} alt={alt} />
      <div className="photo-shade" />
      <div className="photo-copy">
        <span>{eyebrow}</span>
        <strong>{title}</strong>
      </div>
      <span className="photo-arrow">
        <Icon name="arrow" size={17} />
      </span>
    </article>
  );
}

function Metric({
  icon,
  label,
  value,
  accent,
}: {
  icon: "cloud" | "traffic" | "spark";
  label: string;
  value: string;
  accent: string;
}) {
  return (
    <div className="metric">
      <span className={`metric-icon ${accent}`}>
        <Icon name={icon} size={19} />
      </span>
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
      </div>
    </div>
  );
}

function ConditionCard({
  icon,
  label,
  title,
  detail,
  tone,
}: {
  icon: "traffic" | "water" | "work";
  label: string;
  title: string;
  detail: string;
  tone: string;
}) {
  return (
    <article className="condition-card">
      <span className={`condition-icon ${tone}`}>
        <Icon name={icon} size={21} />
      </span>
      <div>
        <span className="condition-label">{label}</span>
        <strong>{title}</strong>
        <p>{detail}</p>
      </div>
    </article>
  );
}

function TravelCard({
  mode,
  plan,
  icon,
  tone,
  children,
  featured,
  image,
  imageAlt,
}: {
  mode: string;
  plan: string;
  icon: "metro" | "bus" | "cab";
  tone: string;
  children: ReactNode;
  featured?: boolean;
  image: string;
  imageAlt: string;
}) {
  return (
    <article className={`travel-card ${featured ? "featured" : ""}`}>
      <div className="travel-visual">
        <img src={image} alt={imageAlt} />
        <span>{mode === "Metro" ? "Namma Metro" : mode === "BMTC Bus" ? "Bengaluru public transit" : "Bengaluru road mobility"}</span>
      </div>
      {featured && (
        <div className="recommendation">
          <Icon name="spark" size={14} />
          AI recommended · 41% confidence
        </div>
      )}
      <div className="travel-head">
        <span className={`mode-icon ${tone}`}>
          <Icon name={icon} size={24} />
        </span>
        <div>
          <span className="plan-label">{plan}</span>
          <h3>{mode}</h3>
        </div>
      </div>
      {children}
    </article>
  );
}

export default function App() {
  const [start, setStart] = useState("Majestic");
  const [destination, setDestination] = useState("Indiranagar");
  const [syncedRoute, setSyncedRoute] = useState({ start, destination });
  const [isSyncing, setIsSyncing] = useState(false);

  function syncRoute() {
    setIsSyncing(true);
    window.setTimeout(() => {
      setSyncedRoute({ start, destination });
      setIsSyncing(false);
    }, 450);
  }

  function swapRoute() {
    setStart(destination);
    setDestination(start);
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Namma Move home">
          <span className="brand-mark">
            <Icon name="pin" size={19} />
          </span>
          <span>
            <strong>Namma Move</strong>
            <small>AI urban mobility</small>
          </span>
        </a>
        <div className="topbar-right">
          <span className="live-pill"><i /> Bengaluru live</span>
          <span className="time">Thursday · 12:53 AM</span>
        </div>
      </header>

      <main id="top">
        <section className="hero">
          <img src={heroImage} alt="Vidhana Soudha illuminated at night in Bengaluru" />
          <div className="hero-overlay" />
          <div className="hero-grid" />
          <div className="hero-content">
            <span className="eyebrow"><Icon name="spark" size={15} /> Bengaluru smart mobility</span>
            <h1>Move smarter<br />through Bengaluru.</h1>
            <p>Real-time traffic, weather, metro status and multimodal travel intelligence for everyday Bengaluru commuters.</p>
            <div className="hero-status">
              <span><i /> City systems online</span>
              <span>Live data intelligence</span>
            </div>
          </div>
          <div className="hero-orbit" aria-hidden="true">
            <span className="orbit-core"><Icon name="spark" size={24} /></span>
            <span className="orbit-label">AI<br />routing</span>
          </div>
        </section>

        <section className="photo-grid" aria-label="Bengaluru mobility highlights">
          <PhotoCard image={skylineImage} alt="Bengaluru urban skyline" eyebrow="City pulse" title="Bengaluru Skyline" />
          <PhotoCard image={metroImage} alt="Namma Metro train in Bengaluru" eyebrow="Public transit" title="Namma Metro" />
          <PhotoCard image={trafficImage} alt="Traffic moving through a Bengaluru flyover corridor" eyebrow="Live intelligence" title="Bengaluru Traffic" />
        </section>

        <section className="route-panel">
          <div className="section-heading">
            <div>
              <span className="section-kicker"><Icon name="spark" size={14} /> AI route intelligence</span>
              <h2>Where are you headed?</h2>
            </div>
            <span className="route-ready"><i /> Ready to plan</span>
          </div>

          <div className="route-controls">
            <label>
              <span>Starting point</span>
              <div className="select-wrap">
                <Icon name="pin" size={19} />
                <select value={start} onChange={(event) => setStart(event.target.value)}>
                  {places.map((place) => <option key={place}>{place}</option>)}
                </select>
              </div>
            </label>
            <button className="swap-button" onClick={swapRoute} aria-label="Swap route">
              <Icon name="swap" size={18} />
            </button>
            <label>
              <span>Destination</span>
              <div className="select-wrap destination">
                <Icon name="pin" size={19} />
                <select value={destination} onChange={(event) => setDestination(event.target.value)}>
                  {places.map((place) => <option key={place}>{place}</option>)}
                </select>
              </div>
            </label>
            <button className="sync-button" onClick={syncRoute} disabled={isSyncing}>
              <Icon name="spark" size={18} />
              {isSyncing ? "Syncing intelligence..." : "Sync route"}
              {!isSyncing && <Icon name="arrow" size={17} />}
            </button>
          </div>
          <div className="synced-copy">
            <span className="route-line-dot" />
            Route synced: <strong>{syncedRoute.start}</strong>
            <span className="route-dash" />
            <strong>{syncedRoute.destination}</strong>
            <span className="route-note">Live conditions applied</span>
          </div>
        </section>

        <section className="conditions-section">
          <div className="section-heading compact">
            <div>
              <span className="section-kicker">Real-time overview</span>
              <h2>Live conditions</h2>
            </div>
            <span className="updated">Last updated · 12:53:22 AM</span>
          </div>
          <div className="metrics-bar">
            <Metric icon="cloud" label="Weather" value="Overcast" accent="sky" />
            <Metric icon="spark" label="Temperature" value="21.7°C" accent="amber" />
            <Metric icon="traffic" label="Road traffic" value="Low traffic" accent="green" />
            <div className="traffic-meter">
              <span>Road flow</span>
              <div><i /></div>
              <strong>Clear</strong>
            </div>
          </div>
          <div className="condition-grid">
            <ConditionCard icon="traffic" label="Road traffic" title="Low traffic" detail="Current 24 km/h · free-flow 24 km/h" tone="green" />
            <ConditionCard icon="water" label="Waterlogging" title="No problem reported" detail="No current flooding incident reported" tone="blue" />
            <ConditionCard icon="work" label="Construction" title="Construction reported" detail="Current roadwork incident reported" tone="amber" />
          </div>
        </section>

        <section className="metro-panel">
          <img className="metro-backdrop" src={metroImage} alt="" />
          <div className="metro-accent" />
          <div className="metro-top">
            <div className="metro-title">
              <span className="mode-icon purple"><Icon name="metro" size={25} /></span>
              <div><span>Namma Metro network</span><h2>Metro line health</h2></div>
            </div>
            <span className="status-badge"><i /> Metro service status</span>
          </div>
          <div className="metro-stats">
            <div><span>Service status</span><strong>Not operating now</strong><small>Outside service hours</small></div>
            <div><span>Frequency</span><strong>Not operating now</strong><small>Resumes at 05:00</small></div>
            <div><span>Service window</span><strong>Approx. 05:00–23:00</strong><small>Daily operations</small></div>
          </div>
          <div className="metro-line">
            <i /><i /><i /><i /><i />
          </div>
        </section>

        <section className="plans-section">
          <div className="section-heading">
            <div>
              <span className="section-kicker">Multimodal comparison</span>
              <h2>Recommended travel plans</h2>
              <p>Compare Metro, BMTC and Namma Yatri options.</p>
            </div>
            <span className="plans-ai"><Icon name="spark" size={15} /> AI ranked</span>
          </div>
          <div className="travel-grid">
            <TravelCard mode="Metro" plan="Plan A" icon="metro" tone="purple" featured image={metroImage} imageAlt="Namma Metro train on the Bengaluru network">
              <div className="primary-stat"><span>ETA</span><strong>Not operating</strong></div>
              <div className="card-divider" />
              <div className="secondary-stats">
                <div><span>Estimated fare</span><strong>—</strong></div>
                <div><span>Frequency</span><strong>Not operating now</strong></div>
              </div>
              <span className="availability">Available from 05:00</span>
            </TravelCard>
            <TravelCard mode="BMTC Bus" plan="Plan B" icon="bus" tone="blue" image={busImage} imageAlt="BMTC bus operating in Bengaluru">
              <div className="primary-stat"><span>ETA</span><strong>38 <small>min</small></strong></div>
              <div className="card-divider" />
              <div className="secondary-stats">
                <div><span>Estimated fare</span><strong>₹15</strong></div>
                <div><span>Nearest BMTC stop</span><strong>Kempegowda Bus Station · 179 m</strong><small>~2 min walk from your location</small></div>
              </div>
            </TravelCard>
            <TravelCard mode="Auto / Cab" plan="Plan C" icon="cab" tone="green" image={roadImage} imageAlt="Bengaluru road and elevated urban mobility corridor">
              <div className="primary-stat"><span>ETA</span><strong>23 <small>min</small></strong></div>
              <div className="card-divider" />
              <div className="secondary-stats two-col">
                <div><span>Estimated fare</span><strong>₹157</strong></div>
                <div><span>Service</span><strong>Namma Yatri</strong></div>
              </div>
              <a className="yatri-button" href="https://nammayatri.in/" target="_blank" rel="noreferrer">
                Open Namma Yatri <Icon name="arrow" size={17} />
              </a>
            </TravelCard>
          </div>
        </section>
      </main>
      <footer><span>Namma Move · Bengaluru commuter intelligence</span><span>Powered by live city data</span></footer>
    </div>
  );
}
